// prisma/seed.ts
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

function randFloat(min = 0, max = 1, decimals = 2) {
  return parseFloat((Math.random() * (max - min) + min).toFixed(decimals));
}

function choose<T>(arr: T[]) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function startOfDay(d: Date) {
  const dd = new Date(d);
  dd.setHours(0, 0, 0, 0);
  return dd;
}

async function main() {
  console.log("Seeding database...");

  // Clear old data
  await prisma.driverStats.deleteMany({});
  await prisma.drivingSummary.deleteMany({});
  await prisma.alert.deleteMany({});
  await prisma.driverLog.deleteMany({});
  await prisma.trip.deleteMany({});
  await prisma.driver.deleteMany({});

  // Create 2 drivers
  const driversData = [
    { name: "Alice Driver", email: "alice@test.com", password: "password123" },
    { name: "Bob Driver", email: "bob@test.com", password: "password123" },
  ];

  const drivers = [];
  for (const d of driversData) {
    const hashed = await bcrypt.hash(d.password, 10);
    const driver = await prisma.driver.create({
      data: { name: d.name, email: d.email, password: hashed, role: "driver" },
    });
    drivers.push(driver);
  }

  // For each driver, create 1 trip with logs, alerts, summary, stats
  for (const driver of drivers) {
    const tripStart = new Date(Date.now() - 1000 * 60 * 60 * 24 * 3); // 3 days ago
    const tripEnd = new Date();

    const trip = await prisma.trip.create({
      data: {
        driverId: driver.id,
        startTime: tripStart,
        endTime: tripEnd,
        durationMin: Math.round(
          (tripEnd.getTime() - tripStart.getTime()) / 60000
        ),
        startLocation: "12.9716,77.5946",
        endLocation: "12.9352,77.6245",
        averageSpeed: 48.5,
        maxSpeed: 122.1,
        weather: "mixed",
        roadCondition: "dry",
      },
    });

    // Create logs
    const logs = [];
    const emotions = ["happy", "tired", "angry", "neutral", "sad", "surprised"];
    const totalMinutes = trip.durationMin;
    const step = Math.max(10, Math.floor(totalMinutes / 150));

    for (let m = 0; m <= totalMinutes; m += step) {
      const ts = new Date(tripStart.getTime() + m * 60 * 1000);
      const hour = ts.getHours();
      const nightFactor =
        hour >= 23 || hour <= 5 ? 0.2 : hour >= 22 || hour <= 6 ? 0.12 : 0;
      let base = randFloat(0.05, 0.6);
      if (Math.random() < 0.03) base += randFloat(0.25, 0.45);
      const drowsiness = Math.min(
        1,
        parseFloat((base + nightFactor + Math.random() * 0.1).toFixed(2))
      );
      const emotion = choose(emotions);
      const microExpression =
        Math.random() < 0.12
          ? choose(["surprise", "anger", "disgust", "fear"])
          : "none";

      logs.push({
        driverId: driver.id,
        tripId: trip.id,
        drowsiness,
        emotion,
        speechMood: choose(["neutral", "tired", "happy", "angry"]),
        eyeAspectRatio: randFloat(0.18, 0.35, 3),
        mouthAspectRatio: randFloat(0.18, 0.4, 3),
        headPose: `${randFloat(-10, 10)}:${randFloat(-15, 15)}:${randFloat(
          -5,
          5
        )}`,
        blinkDetected: Math.random() < 0.3,
        microExpression,
        speechVolume: randFloat(40, 75),
        speechRate: randFloat(1.5, 3.5, 2),
        timestamp: ts,
      });
    }

    await prisma.driverLog.createMany({ data: logs });

    // Generate alerts if drowsiness > 0.7 or speech/emotion triggers
    const alerts = logs
      .filter(
        (l) => l.drowsiness! > 0.7 || ["angry", "tired"].includes(l.emotion!)
      )
      .map((l) => ({
        driverId: driver.id,
        tripId: trip.id,
        type: l.drowsiness! > 0.7 ? "DROWSINESS" : "EMOTION",
        level: l.drowsiness! > 0.7 ? l.drowsiness : 0.5,
        message:
          l.drowsiness! > 0.7
            ? "High drowsiness detected"
            : `Emotion alert: ${l.emotion}`,
        acknowledged: false,
        resolved: false,
        createdAt: l.timestamp,
      }));

    if (alerts.length) await prisma.alert.createMany({ data: alerts });

    // Driving summary for the trip
    const avgDrowsiness =
      logs.reduce((sum, l) => sum + (l.drowsiness || 0), 0) / logs.length;
    const mostFrequentEmotion = Object.entries(
      logs.reduce((acc: Record<string, number>, l) => {
        const e = l.emotion || "neutral";
        acc[e] = (acc[e] || 0) + 1;
        return acc;
      }, {})
    ).sort((a, b) => b[1] - a[1])[0][0];

    await prisma.drivingSummary.create({
      data: {
        driverId: driver.id,
        tripId: trip.id,
        avgDrowsiness: parseFloat(avgDrowsiness.toFixed(2)),
        mostFrequentEmotion,
        speechMoodSummary: choose(["neutral", "tired", "happy", "angry"]),
        drivingScore: parseFloat((100 - avgDrowsiness * 100).toFixed(2)),
        suggestions: avgDrowsiness > 0.6 ? "Take a break" : "Drive carefully",
      },
    });

    // Daily driver stats for the last 3 days
    for (let d = 0; d < 3; d++) {
      const date = startOfDay(new Date(Date.now() - 1000 * 60 * 60 * 24 * d));
      const dailyLogs = logs.filter(
        (l) =>
          l.timestamp >= date &&
          l.timestamp < new Date(date.getTime() + 24 * 60 * 60 * 1000)
      );
      if (!dailyLogs.length) continue;

      const dailyAvgDrowsiness =
        dailyLogs.reduce((sum, l) => sum + (l.drowsiness || 0), 0) /
        dailyLogs.length;
      const dailyFrequentEmotion = Object.entries(
        dailyLogs.reduce((acc: Record<string, number>, l) => {
          const e = l.emotion || "neutral";
          acc[e] = (acc[e] || 0) + 1;
          return acc;
        }, {})
      ).sort((a, b) => b[1] - a[1])[0][0];
      const dailyTotalAlerts = alerts.filter(
        (a) =>
          a.createdAt >= date &&
          a.createdAt < new Date(date.getTime() + 24 * 60 * 60 * 1000)
      ).length;

      await prisma.driverStats.create({
        data: {
          driverId: driver.id,
          date,
          avgDrowsiness: parseFloat(dailyAvgDrowsiness.toFixed(2)),
          frequentEmotion: dailyFrequentEmotion,
          totalAlerts: dailyTotalAlerts,
        },
      });
    }
  }

  console.log(
    "Seeding complete with 2 drivers, trips, logs, alerts, summaries, and stats."
  );
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
