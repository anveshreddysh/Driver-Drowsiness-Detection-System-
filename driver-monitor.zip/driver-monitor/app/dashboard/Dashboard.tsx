"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import DrowsinessChart from "@/components/DrowsinessChart";
import EmotionChart from "@/components/EmotionChart";
import DashboardSummary from "@/components/DashboardSummary";
import { getToken, requireAuth } from "@/lib/auth";

interface DriverLog {
  id: string;
  drowsiness?: number;
  emotion?: string;
  createdAt: string;
}

export default function Dashboard() {
  const router = useRouter();
  const [logs, setLogs] = useState<DriverLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    requireAuth();
    const driverId = localStorage.getItem("driverId");
    if (!driverId) return;

    const fetchLogs = async () => {
      try {
        const token = getToken();
        const res = await fetch(`/api/logs/driver?driverId=${driverId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!res.ok) throw new Error("Failed to fetch logs");
        const data = await res.json();
        setLogs(data.logs);
      } catch (err: any) {
        toast.error(err.message);
        router.push("/login");
      } finally {
        setLoading(false);
      }
    };

    fetchLogs();
  }, [router]);

  if (loading) return <p className="text-center mt-20">Loading dashboard...</p>;

  return (
    <div className="min-h-screen p-8 bg-gray-50">
      <h1 className="text-3xl font-bold mb-6 text-gray-800">
        Driver Dashboard
      </h1>
      <DashboardSummary logs={logs} />

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mt-8 items-start">
        <div className="md:col-span-3">
          <DrowsinessChart logs={logs} />
        </div>
        <div className="md:col-span-1">
          <EmotionChart logs={logs} />
        </div>
      </div>
    </div>
  );
}
