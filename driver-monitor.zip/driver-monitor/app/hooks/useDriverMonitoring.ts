// app/hooks/useDriverMonitoring.ts
import { useEffect, useRef, useState } from "react";
import type { LandmarksData } from "./useFaceDetection";
import { useSoundAnalysis } from "./useSoundAnalysis";

export interface MonitoringResult {
  status: "DROWSY" | "AWAKE";
  drowsyScore: number; // 0–1
  drowsyHistory: number[];
  emotionHistory: string[];
  calibrationProgress: number;
  blinkCount: number;
  blinkDetected: boolean;
  dominantEmotion?: string;
  soundWarning?: boolean;
  continuousClose?: boolean; // immediate close flag
  perclos?: number; // 0..1 PERCLOS
  startCalibration: () => void;
  stopCalibration: () => void;
}

export function useDriverMonitoring(
  landmarksData: LandmarksData | null,
  maxPoints: number = 60
): MonitoringResult {
  const [status, setStatus] = useState<"DROWSY" | "AWAKE">("AWAKE");
  const [drowsyScore, setDrowsyScore] = useState<number>(0);
  const [drowsyHistory, setDrowsyHistory] = useState<number[]>([]);
  const [emotionHistory, setEmotionHistory] = useState<string[]>([]);
  const [calibrationProgress, setCalibrationProgress] = useState<number>(0);
  const [blinkCount, setBlinkCount] = useState<number>(0);
  const [blinkDetected, setBlinkDetected] = useState<boolean>(false);
  const [dominantEmotion, setDominantEmotion] = useState<string>("neutral");
  const [soundWarning, setSoundWarning] = useState<boolean>(false);
  const [continuousClose, setContinuousClose] = useState<boolean>(false);
  const [perclosState, setPerclosState] = useState<number>(0);

  const prevEyesClosed = useRef<boolean>(false);
  const lastEyeStateRef = useRef<{ closed: boolean; lastChangeTs: number }>({
    closed: false,
    lastChangeTs: Date.now(),
  });
  const percBufferRef = useRef<{ ts: number; closed: 0 | 1 }[]>([]);
  const lastContinuousCloseAlertRef = useRef<number>(0);
  const longBlinkCountRef = useRef<number>(0);

  const lastPitchRef = useRef<number | null>(null);
  const lastPitchTsRef = useRef<number | null>(null);
  const emaRef = useRef<number>(0);

  // Calibration
  const calibratingRef = useRef<boolean>(false);
  const calibrationStartTsRef = useRef<number | null>(null);
  const calibrationSamplesRef = useRef<number[]>([]);
  const calibrationDurationMs = 10_000; // 10s baseline (demo-friendly)

  const {
    volume,
    bandEnergyLow,
    isSilent,
    isRunning,
    permissionGranted,
    recentEnvelope,
  } = useSoundAnalysis();

  // ========== DEMO-SENSITIVE CONFIG ==========
  const PERCLOS_WINDOW_MS = 30_000; // 30s window
  const PERCLOS_ALERT = 0.18;
  const CONTINUOUS_CLOSE_MS_ALERT = 800;
  const LONG_BLINK_MS = 350;
  const YAWN_MAR_NORMALIZE = 0.55;
  const HEAD_NOD_ANGLE_DEG = 7;
  const HEAD_NOD_VEL_DEG_PER_S = 5;
  const SOUND_SUPPORT_WEIGHT = 0.25;
  const SMOOTH_ALPHA = 0.45;
  // ===========================================

  const baselineEarRef = useRef<number | null>(null);
  const EAR_CLOSED_REF = useRef<number>(0.22);
  const EAR_OPEN_REF = useRef<number>(0.28);

  const dist = (a: { x: number; y: number }, b: { x: number; y: number }) =>
    Math.hypot(a.x - b.x, a.y - b.y);

  const median = (arr: number[]) => {
    const s = [...arr].sort((a, b) => a - b);
    const m = Math.floor(s.length / 2);
    return s.length % 2 === 1 ? s[m] : (s[m - 1] + s[m]) / 2;
  };
  const std = (arr: number[]) => {
    if (!arr.length) return 0;
    const mean = arr.reduce((s, x) => s + x, 0) / arr.length;
    return Math.sqrt(
      arr.reduce((s, x) => s + (x - mean) * (x - mean), 0) / arr.length
    );
  };

  const detectPeaks = (
    values: number[],
    times: number[],
    minAmp = 14,
    minSeparationMs = 150,
    prominenceStd = 1.0
  ) => {
    const peaks: { idx: number; t: number; v: number }[] = [];
    if (!values.length) return peaks;
    const med = median(values);
    const s = std(values);
    for (let i = 1; i < values.length - 1; i++) {
      const v = values[i];
      if (v > values[i - 1] && v >= values[i + 1]) {
        const t = times[i] ?? Date.now();
        if (peaks.length && t - peaks[peaks.length - 1].t < minSeparationMs)
          continue;
        const prominenceOk = s > 0 ? v >= med + prominenceStd * s : true;
        if (prominenceOk && v >= minAmp) peaks.push({ idx: i, t, v });
      }
    }
    return peaks;
  };

  const evaluatePeriodicity = (
    peaks: { idx: number; t: number; v: number }[],
    minPeaks = 3,
    maxIntervalStdMs = 500
  ) => {
    if (peaks.length < minPeaks)
      return { ok: false, intervals: [] as number[] };
    const intervals: number[] = [];
    for (let i = 1; i < peaks.length; i++)
      intervals.push(peaks[i].t - peaks[i - 1].t);
    const meanI = intervals.reduce((s, x) => s + x, 0) / intervals.length;
    const stdI = std(intervals);
    if (stdI <= maxIntervalStdMs && meanI >= 200 && meanI <= 2000)
      return { ok: true, intervals };
    return { ok: false, intervals };
  };

  // calibration controls
  const startCalibration = () => {
    calibrationSamplesRef.current = [];
    calibrationStartTsRef.current = Date.now();
    calibratingRef.current = true;
    setCalibrationProgress(0);
  };
  const stopCalibration = () => {
    calibratingRef.current = false;
    calibrationStartTsRef.current = null;
    if (calibrationSamplesRef.current.length) {
      const avg =
        calibrationSamplesRef.current.reduce((s, x) => s + x, 0) /
        calibrationSamplesRef.current.length;
      baselineEarRef.current = avg;
      EAR_CLOSED_REF.current = Math.max(0.12, avg * 0.6);
      EAR_OPEN_REF.current = Math.max(
        EAR_CLOSED_REF.current + 0.04,
        avg * 0.75
      );
      setCalibrationProgress(1);
    } else {
      setCalibrationProgress(1);
    }
  };

  // -----------------------------------------------------------------------
  // Add throttling and previous-value refs to avoid state churn / infinite loops
  const lastUpdateRef = useRef<number>(0);
  const prevValuesRef = useRef<{
    drowsyScore?: number;
    perclos?: number;
    continuousClose?: boolean;
    blinkCount?: number;
    dominantEmotion?: string;
    soundWarning?: boolean;
  }>({});
  const UPDATE_MS = 180; // ~5-6 updates/sec

  useEffect(() => {
    // early exit
    if (!landmarksData) return;

    const nowTs = Date.now();
    // throttle frequent runs
    if (nowTs - (lastUpdateRef.current || 0) < UPDATE_MS) return;
    lastUpdateRef.current = nowTs;

    const { landmarks, expressions } = landmarksData;

    // eyes
    const leftEye = landmarks.slice(36, 42);
    const rightEye = landmarks.slice(42, 48);
    const computeEAR = (eye: { x: number; y: number }[]) =>
      (dist(eye[1], eye[5]) + dist(eye[2], eye[4])) /
      (2 * dist(eye[0], eye[3]));
    const earLeft = computeEAR(leftEye);
    const earRight = computeEAR(rightEye);
    const EAR = (earLeft + earRight) / 2;

    // calibration accumulation
    if (calibratingRef.current && calibrationStartTsRef.current != null) {
      calibrationSamplesRef.current.push(EAR);
      const elapsed = nowTs - calibrationStartTsRef.current;
      const progress = Math.min(1, elapsed / calibrationDurationMs);
      // update progress only if changed meaningfully
      setCalibrationProgress((prev) =>
        Math.abs(prev - progress) > 0.01 ? progress : prev
      );
      if (elapsed >= calibrationDurationMs) stopCalibration();
    }

    const EAR_CLOSED = EAR_CLOSED_REF.current;
    const EAR_OPEN = EAR_OPEN_REF.current;

    const eyesCurrentlyClosed = prevEyesClosed.current
      ? EAR < EAR_OPEN
      : EAR < EAR_CLOSED;

    // blink detection (only update on change)
    if (eyesCurrentlyClosed !== lastEyeStateRef.current.closed) {
      const prevState = lastEyeStateRef.current;
      const durationMs = nowTs - prevState.lastChangeTs;
      if (prevState.closed && durationMs >= LONG_BLINK_MS) {
        longBlinkCountRef.current += 1;
        setBlinkCount((p) => p + 1);
        setBlinkDetected(true);
        setTimeout(() => setBlinkDetected(false), 300);
      } else {
        setBlinkDetected(false);
      }
      lastEyeStateRef.current = {
        closed: eyesCurrentlyClosed,
        lastChangeTs: nowTs,
      };
    }
    prevEyesClosed.current = eyesCurrentlyClosed;

    // PERCLOS
    percBufferRef.current.push({
      ts: nowTs,
      closed: eyesCurrentlyClosed ? 1 : 0,
    });
    while (
      percBufferRef.current.length &&
      percBufferRef.current[0].ts < nowTs - PERCLOS_WINDOW_MS
    ) {
      percBufferRef.current.shift();
    }
    const closedSum = percBufferRef.current.reduce((s, x) => s + x.closed, 0);
    const windowLen = Math.max(1, percBufferRef.current.length);
    const perclos = closedSum / windowLen;

    // continuous close
    const lastChange = lastEyeStateRef.current.lastChangeTs;
    const continuousClosedMs = eyesCurrentlyClosed ? nowTs - lastChange : 0;
    const continuousCloseTriggered =
      continuousClosedMs >= CONTINUOUS_CLOSE_MS_ALERT;

    // mouth / MAR
    const mouth = landmarks.slice(60, 68);
    const MAR =
      (dist(mouth[2], mouth[6]) +
        dist(mouth[3], mouth[5]) +
        dist(mouth[1], mouth[7])) /
      (2 * dist(mouth[0], mouth[4]));
    const MAR_score = Math.min(1, MAR / YAWN_MAR_NORMALIZE);

    // head nod / pitch
    const leftEyeCenter = leftEye.reduce(
      (acc, p) => ({
        x: acc.x + p.x / leftEye.length,
        y: acc.y + p.y / leftEye.length,
      }),
      { x: 0, y: 0 }
    );
    const rightEyeCenter = rightEye.reduce(
      (acc, p) => ({
        x: acc.x + p.x / rightEye.length,
        y: acc.y + p.y / rightEye.length,
      }),
      { x: 0, y: 0 }
    );
    const eyeCenter = {
      x: (leftEyeCenter.x + rightEyeCenter.x) / 2,
      y: (leftEyeCenter.y + rightEyeCenter.y) / 2,
    };
    const nose = landmarks[30] ?? landmarks[Math.floor(landmarks.length / 2)];
    const vx = nose.x - eyeCenter.x;
    const vy = nose.y - eyeCenter.y;
    const pitchRad = Math.atan2(vy, Math.max(1e-6, Math.abs(vx)));
    const pitchDeg = pitchRad * (180 / Math.PI);

    let pitchVel = 0;
    if (lastPitchRef.current != null && lastPitchTsRef.current != null) {
      const dt = (nowTs - lastPitchTsRef.current) / 1000;
      if (dt > 0) pitchVel = (pitchDeg - lastPitchRef.current) / dt;
    }
    lastPitchRef.current = pitchDeg;
    lastPitchTsRef.current = nowTs;

    const headNodDetected =
      pitchDeg > HEAD_NOD_ANGLE_DEG && pitchVel > HEAD_NOD_VEL_DEG_PER_S;

    // SOUND scoring (guarded)
    let soundScore = 0;
    let detectedSoundWarning = false;
    try {
      const { envelope, times } = recentEnvelope(256);
      if (envelope && envelope.length >= 8) {
        const envSm = envelope.map((_, i, arr) => {
          const start = Math.max(0, i - 2);
          const slice = arr.slice(start, i + 1);
          return slice.reduce((s, x) => s + x, 0) / slice.length;
        });
        const peaks = detectPeaks(envSm, times, 14, 150, 1.0);
        const periodic = evaluatePeriodicity(peaks, 3, 500);
        if (periodic.ok) {
          const factor = Math.min(1, peaks.length / 6);
          soundScore += 1 * factor;
          detectedSoundWarning = true;
        } else if ((bandEnergyLow ?? 0) > 0.25) {
          soundScore += 0.5;
          detectedSoundWarning = true;
        }
      } else {
        if ((bandEnergyLow ?? 0) > 0.25) {
          soundScore += 0.4;
          detectedSoundWarning = true;
        }
      }
    } catch (e) {
      // keep it quiet; sound scoring shouldn't crash the hook
      // console.error("sound scoring error:", e);
    }
    soundScore = Math.max(0, Math.min(1, soundScore));

    // combine weighted components
    const W_EYES = 0.65;
    const W_PERCLOS = 0.4;
    const W_MAR = 0.35;
    const W_HEAD = 0.4;
    const W_SOUND = SOUND_SUPPORT_WEIGHT;

    const eyesInstant = continuousCloseTriggered
      ? 1
      : eyesCurrentlyClosed
      ? 0.6
      : 0;
    const perclosComponent = Math.min(1, perclos / PERCLOS_ALERT);
    const marComponent = MAR_score;
    const headComponent = headNodDetected
      ? 1
      : Math.min(1, Math.max(0, pitchDeg / 30));
    const soundComponent = soundScore;

    let newScoreUnsmoothed =
      W_EYES * eyesInstant +
      W_PERCLOS * perclosComponent +
      W_MAR * marComponent +
      W_HEAD * headComponent +
      W_SOUND * soundComponent;

    if (!Number.isFinite(newScoreUnsmoothed)) newScoreUnsmoothed = 0;
    newScoreUnsmoothed = Math.max(0, Math.min(1, newScoreUnsmoothed));

    // EMA smoothing
    const prevEma = emaRef.current ?? drowsyScore ?? 0;
    const ema =
      prevEma * (1 - SMOOTH_ALPHA) + newScoreUnsmoothed * SMOOTH_ALPHA;
    emaRef.current = ema;

    // --- Set state only when values changed meaningfully ---
    // drowsyScore
    if (Math.abs((prevValuesRef.current.drowsyScore ?? 0) - ema) > 0.005) {
      prevValuesRef.current.drowsyScore = ema;
      setDrowsyScore(ema);
    }

    const isDrowsy = ema > 0.5;
    // drowsyHistory: append 0/1 at throttled rate (keep history length)
    setDrowsyHistory((prev) => {
      const next = [...prev.slice(-maxPoints + 1), isDrowsy ? 1 : 0];
      return next;
    });

    // perclos
    if (Math.abs((prevValuesRef.current.perclos ?? 0) - perclos) > 0.002) {
      prevValuesRef.current.perclos = perclos;
      setPerclosState(perclos);
    }

    // continuousClose
    if (
      (prevValuesRef.current.continuousClose ?? false) !==
      continuousCloseTriggered
    ) {
      prevValuesRef.current.continuousClose = continuousCloseTriggered;
      setContinuousClose(continuousCloseTriggered);
    }

    // emotion extraction (stable compare)
    let emotion = "neutral";
    if (expressions && typeof expressions === "object") {
      try {
        const exp = expressions as unknown as Record<string, number>;
        const best = Object.entries(exp).reduce(
          (a, b) => (a[1] > b[1] ? a : b),
          ["neutral", 0] as [string, number]
        );
        emotion = best[0] ?? "neutral";
      } catch {
        emotion = "neutral";
      }
    }
    if ((prevValuesRef.current.dominantEmotion ?? "") !== emotion) {
      prevValuesRef.current.dominantEmotion = emotion;
      setEmotionHistory((prev) => [...prev.slice(-maxPoints + 1), emotion]);
      setDominantEmotion(emotion);
    } else {
      // still keep the history update at throttled cadence
      setEmotionHistory((prev) => [...prev.slice(-maxPoints + 1), emotion]);
    }

    // status
    const newStatus: "DROWSY" | "AWAKE" = isDrowsy ? "DROWSY" : "AWAKE";
    setStatus(newStatus);

    // blinkCount is only incremented above when a long blink detected; prevValuesRef used for safety
    if ((prevValuesRef.current.blinkCount ?? 0) !== longBlinkCountRef.current) {
      prevValuesRef.current.blinkCount = longBlinkCountRef.current;
      setBlinkCount(longBlinkCountRef.current);
    }

    // soundWarning
    if (
      (prevValuesRef.current.soundWarning ?? false) !== detectedSoundWarning
    ) {
      prevValuesRef.current.soundWarning = detectedSoundWarning;
      setSoundWarning(detectedSoundWarning);
    }

    // done — effect dependencies below
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    landmarksData,
    bandEnergyLow,
    volume,
    isSilent,
    isRunning,
    // intentionally NOT including recentEnvelope here because it's a function
    // and may change identity; we call it inside; throttling prevents overload.
  ]);

  return {
    status,
    drowsyScore,
    drowsyHistory,
    emotionHistory,
    calibrationProgress,
    blinkCount,
    blinkDetected,
    dominantEmotion,
    soundWarning,
    continuousClose,
    perclos: perclosState,
    startCalibration,
    stopCalibration,
  };
}
