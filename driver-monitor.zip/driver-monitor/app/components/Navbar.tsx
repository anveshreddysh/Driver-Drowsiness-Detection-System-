"use client";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";

export default function Navbar() {
  const router = useRouter();
  const pathname = usePathname();
  const [loggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const token = localStorage.getItem("token");
      setLoggedIn(!!token);
    }
  }, [pathname]); // recheck when route changes

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("driverId");
    toast.success("Logged out");
    router.push("/login");
  };

  // Hide navbar on login page
  if (pathname === "/login") return null;

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="mx-auto max-w-7xl px-6 py-4 flex justify-between items-center">
        <h1
          className="text-xl font-bold text-blue-600 cursor-pointer"
          onClick={() => router.push("/")}
        >
          Driver Monitoring
        </h1>

        {loggedIn && (
          <div className="flex items-center space-x-4">
            <button
              onClick={() => router.push("/")}
              className={`text-gray-700 hover:text-blue-600 ${
                pathname === "/" ? "font-semibold" : ""
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => router.push("/live")}
              className={`text-gray-700 hover:text-blue-600 ${
                pathname === "/live" ? "font-semibold" : ""
              }`}
            >
              Live
            </button>
            <button
              onClick={handleLogout}
              className="bg-blue-600 text-white px-4 py-1 rounded-lg hover:bg-blue-700 transition"
            >
              Logout
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
