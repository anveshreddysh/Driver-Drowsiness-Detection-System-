"use client";

import { useState, useMemo } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend
);

export default function DrowsinessChart({ logs }: { logs: any[] }) {
  const [view, setView] = useState<"hourly" | "daily" | "weekly">("hourly");

  // 🧮 Helper function to group logs by selected view
  const aggregatedLogs = useMemo(() => {
    const grouped: Record<string, { sum: number; count: number }> = {};

    for (const log of logs) {
      const d = new Date(log.timestamp);
      if (isNaN(d.getTime())) continue;

      let key = "";

      if (view === "hourly") {
        key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(
          2,
          "0"
        )}-${String(d.getDate()).padStart(2, "0")} ${String(
          d.getHours()
        ).padStart(2, "0")}:00`;
      } else if (view === "daily") {
        key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(
          2,
          "0"
        )}-${String(d.getDate()).padStart(2, "0")}`;
      } else if (view === "weekly") {
        const firstDayOfYear = new Date(d.getFullYear(), 0, 1);
        const weekNumber = Math.ceil(
          ((d.getTime() - firstDayOfYear.getTime()) / 86400000 +
            firstDayOfYear.getDay() +
            1) /
            7
        );
        key = `${d.getFullYear()}-W${weekNumber}`;
      }

      if (!grouped[key]) grouped[key] = { sum: 0, count: 0 };
      grouped[key].sum += log.drowsiness ?? 0;
      grouped[key].count += 1;
    }

    return Object.entries(grouped)
      .map(([period, { sum, count }]) => ({
        period,
        avg: sum / count,
      }))
      .sort(
        (a, b) => new Date(a.period).getTime() - new Date(b.period).getTime()
      );
  }, [logs, view]);

  // 🎨 Prepare chart data
  const data = {
    labels: aggregatedLogs.map((entry) => {
      const d = new Date(entry.period);
      if (view === "hourly")
        return d.toLocaleString([], {
          month: "short",
          day: "numeric",
          hour: "numeric",
        });
      if (view === "daily")
        return d.toLocaleDateString([], { month: "short", day: "numeric" });
      return entry.period; // weekly labels like "2025-W44"
    }),
    datasets: [
      {
        label:
          view === "hourly"
            ? "Average Drowsiness (Hourly)"
            : view === "daily"
            ? "Average Drowsiness (Daily)"
            : "Average Drowsiness (Weekly)",
        data: aggregatedLogs.map((entry) => entry.avg),
        borderColor: "rgb(37, 99, 235)",
        backgroundColor: "rgba(37, 99, 235, 0.2)",
        tension: 0.3,
        fill: true,
        pointRadius: 3,
        pointHoverRadius: 6,
      },
    ],
  };

  // ⚙️ Chart options
  const options = {
    responsive: true,
    plugins: {
      legend: { display: true },
      tooltip: {
        callbacks: {
          label: (context: any) =>
            `Avg Drowsiness: ${context.parsed.y.toFixed(2)}`,
        },
      },
    },
    scales: {
      y: {
        min: 0,
        max: 1,
        title: { display: true, text: "Drowsiness Level" },
      },
      x: {
        title: {
          display: true,
          text: view.charAt(0).toUpperCase() + view.slice(1),
        },
      },
    },
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-md h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Drowsiness Trends</h2>
        {/* <select
          className="border border-gray-300 rounded-md px-2 py-1 text-sm"
          value={view}
          onChange={(e) => setView(e.target.value as any)}
        >
          <option value="hourly">Hourly</option>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
        </select> */}
      </div>

      <Line data={data} options={options} />
    </div>
  );
}
