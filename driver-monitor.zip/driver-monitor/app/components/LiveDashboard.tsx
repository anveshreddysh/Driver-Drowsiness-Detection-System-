"use client";

import { useEffect, useRef, useState } from "react";
import { Toaster, toast } from "react-hot-toast";
import { VideoCard } from "@/components/VideoCard";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Line, Bar } from "react-chartjs-2";
import { useSoundAnalysis } from "@/hooks/useSoundAnalysis";
import { useFaceDetection } from "@/hooks/useFaceDetection";
import { useDriverMonitoring } from "@/hooks/useDriverMonitoring";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const MAX_LOGS = 180;

const safeToast = {
  success: (m: string, o?: any) =>
    typeof window !== "undefined" && setTimeout(() => toast.success(m, o), 0),
  error: (m: string, o?: any) =>
    typeof window !== "undefined" && setTimeout(() => toast.error(m, o), 0),
  info: (m: string, o?: any) =>
    typeof window !== "undefined" && setTimeout(() => toast(m, o), 0),
};

export default function SimplifiedLiveDashboard({
  driverId,
}: {
  driverId?: string;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [logs, setLogs] = useState<any[]>([]);
  const [showDebug, setShowDebug] = useState(false);
  const [demoMode, setDemoMode] = useState(false);

  const lastAlertRef = useRef<number>(0);
  const lastSoundInfoRef = useRef<number>(0);

  const {
    volume,
    bandEnergyLow,
    isSilent,
    isRunning,
    permissionGranted,
    start,
    stop,
    recentEnvelope,
  } = useSoundAnalysis();
  const landmarksData = useFaceDetection(videoRef);
  const {
    status,
    drowsyScore,
    drowsyHistory,
    emotionHistory,
    calibrationProgress,
    blinkCount,
    blinkDetected,
    dominantEmotion,
    soundWarning,
    continuousClose,
    perclos,
    startCalibration,
    stopCalibration,
  } = useDriverMonitoring(landmarksData, MAX_LOGS);

  const continuousFlag = demoMode ? continuousClose : continuousClose;
  const perclosValue = perclos ?? 0;
  const soundFlag = demoMode ? soundWarning : soundWarning;

  useEffect(() => {
    if (!landmarksData) return;

    const dist = (a: any, b: any) => Math.hypot(a.x - b.x, a.y - b.y);

    const computeEAR = (lm: any[] = []) => {
      if (!lm || lm.length < 48) return 0;
      const leftEye = lm.slice(36, 42);
      const rightEye = lm.slice(42, 48);
      return (
        (dist(leftEye[1], leftEye[5]) +
          dist(leftEye[2], leftEye[4]) +
          dist(rightEye[1], rightEye[5]) +
          dist(rightEye[2], rightEye[4])) /
        (2 * (dist(leftEye[0], leftEye[3]) + dist(rightEye[0], rightEye[3])))
      );
    };

    const computeMAR = (lm: any[] = []) => {
      if (!lm || lm.length < 68) return 0;
      const mouth = lm.slice(60, 68);
      return (
        (dist(mouth[1], mouth[7]) +
          dist(mouth[2], mouth[6]) +
          dist(mouth[3], mouth[5])) /
        (2 * dist(mouth[0], mouth[4]))
      );
    };

    const ear = computeEAR(landmarksData.landmarks);
    const mar = computeMAR(landmarksData.landmarks);
    const ts = Date.now();
    const metrics = {
      ear,
      mar,
      drowsyScore,
      speechVolume: Math.round((volume ?? 0) * 100),
      lowBandPct: Math.round((bandEnergyLow ?? 0) * 100),
      emotion: dominantEmotion ?? "neutral",
      blinkCount,
      isSilent,
      isRunning,
      soundWarning,
      continuousClose,
      perclos: perclosValue,
      timestamp: new Date(ts).toLocaleTimeString(),
      ts,
    };

    setLogs((p) => [...p.slice(-MAX_LOGS + 1), { id: ts, ...metrics }]);
  }, [
    landmarksData,
    drowsyScore,
    volume,
    bandEnergyLow,
    blinkCount,
    dominantEmotion,
    isSilent,
    isRunning,
    soundWarning,
    continuousClose,
    perclos,
  ]);

  // simple alerting (kept compact)
  useEffect(() => {
    const now = Date.now();
    const DROWSY_THRESHOLD = demoMode ? 0.4 : 0.6;
    const ALERT_DEBOUNCE_MS = demoMode ? 3000 : 10000;

    if (continuousFlag && now - lastAlertRef.current > ALERT_DEBOUNCE_MS) {
      lastAlertRef.current = now;
      safeToast.error(
        "Immediate danger: eyes closed for an extended time. Pull over NOW."
      );
      try {
        new Audio("/alert.mp3").play().catch(() => {});
      } catch {}
      return;
    }

    if (
      perclosValue >= (demoMode ? 0.18 : 0.25) &&
      now - lastAlertRef.current > ALERT_DEBOUNCE_MS
    ) {
      lastAlertRef.current = now;
      safeToast.error(
        "Elevated eye-closure detected (PERCLOS). Please stay alert."
      );
      try {
        new Audio("/alert.mp3").play().catch(() => {});
      } catch {}
      return;
    }

    // drowsy score crossing detection (simple edge)
    if (
      drowsyScore >= DROWSY_THRESHOLD &&
      now - lastAlertRef.current > ALERT_DEBOUNCE_MS
    ) {
      lastAlertRef.current = now;
      safeToast.error(
        drowsyScore && soundFlag
          ? "Drowsiness detected + sound pattern — immediate attention required!"
          : "Drowsiness detected — please take a break."
      );
      try {
        new Audio("/alert.mp3").play().catch(() => {});
      } catch {}
      return;
    }

    if (soundFlag && now - lastSoundInfoRef.current > 5000) {
      lastSoundInfoRef.current = now;
      safeToast.info(
        "Low-frequency audio pattern detected — possible snoring."
      );
    }
  }, [drowsyScore, soundFlag, continuousFlag, perclosValue, demoMode]);

  // lightweight smoothing
  const smooth = (arr: number[]) =>
    arr.map((v, i) => {
      const window = arr.slice(Math.max(0, i - 2), i + 1);
      return window.reduce((a, b) => a + b, 0) / window.length;
    });

  const timestamps = logs.map((l) => l.timestamp);
  const earData = smooth(logs.map((l) => l.ear ?? 0));
  const marData = smooth(logs.map((l) => l.mar ?? 0));
  const drowsyData = smooth(logs.map((l) => l.drowsyScore ?? 0));
  const speechVolumeData = smooth(logs.map((l) => l.speechVolume ?? 0));
  const lowBandData = smooth(logs.map((l) => l.lowBandPct ?? 0));

  const emotionsCount: Record<string, number> = {};
  logs.forEach((l) => {
    const e = l.emotion || "neutral";
    emotionsCount[e] = (emotionsCount[e] || 0) + 1;
  });
  const emotionLabels = Object.keys(emotionsCount);
  const emotionCounts = Object.values(emotionsCount);

  // demo helpers (simple)
  const simulate = (type: "close" | "snore", dur = 4000) => {
    if (!demoMode) {
      safeToast.info("Enable demo mode to simulate");
      return;
    }
    safeToast.info(
      type === "close" ? "Simulating eye closure" : "Simulating snore"
    );
    // quick temporary state change to trigger alerts via hooks
    if (type === "close") {
      // no local state here, rely on existing demo wiring if present in hooks
      setTimeout(() => safeToast.info("Simulation ended"), dur);
    } else {
      setTimeout(() => safeToast.info("Simulation ended"), dur);
    }
  };

  return (
    <div className="p-4 space-y-6">
      <Toaster />

      <div className="flex justify-between items-center">
        <h1 className="text-xl font-semibold">Live Driver Dashboard</h1>

        {/* Compact control group (fewer buttons) */}
        <div className="flex items-center gap-2">
          <button
            onClick={async () => {
              try {
                await start();
                safeToast.success("Microphone started");
              } catch (e: any) {
                safeToast.error(
                  "Could not start microphone: " + (e?.message ?? e)
                );
              }
            }}
            className="px-3 py-1 bg-green-600 text-white rounded text-sm"
          >
            Start Mic
          </button>

          <button
            onClick={() => {
              stop();
              safeToast.info("Microphone stopped");
            }}
            className="px-3 py-1 bg-red-600 text-white rounded text-sm"
          >
            Stop Mic
          </button>

          <button
            onClick={() => {
              // toggle calibration
              if (calibrationProgress > 0 && calibrationProgress < 1) {
                if (typeof stopCalibration === "function") {
                  stopCalibration();
                  safeToast.info("Calibration stopped");
                }
              } else {
                if (typeof startCalibration === "function") {
                  startCalibration();
                  safeToast.info("Calibration started — keep eyes open");
                }
              }
            }}
            className="px-3 py-1 bg-blue-600 text-white rounded text-sm"
          >
            {calibrationProgress > 0 && calibrationProgress < 1
              ? "Stop Cal"
              : "Calibrate"}
          </button>

          <button
            onClick={() => setDemoMode((s) => !s)}
            className={`px-3 py-1 rounded text-sm ${
              demoMode ? "bg-indigo-700 text-white" : "bg-gray-200 text-black"
            }`}
          >
            {demoMode ? "Demo ON" : "Demo OFF"}
          </button>

          <div className="relative inline-block">
            <button
              onClick={() => setShowDebug((s) => !s)}
              className="px-3 py-1 bg-gray-700 text-white rounded text-sm"
            >
              {showDebug ? "Hide Debug" : "Show Debug"}
            </button>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="relative w-full h-96 rounded-lg shadow-lg bg-black/5 overflow-hidden">
          <VideoCard
            videoRef={videoRef}
            className="w-full h-full object-cover rounded-lg"
          />

          {drowsyScore >= (demoMode ? 0.5 : 0.6) && (
            <div className="absolute top-3 right-3 bg-red-600 text-white px-3 py-1 rounded animate-pulse">
              DROWSY {(drowsyScore * 100).toFixed(0)}%
            </div>
          )}

          {blinkDetected && (
            <div className="absolute bottom-3 left-3 bg-blue-500 text-white px-3 py-1 rounded">
              Blink {blinkCount}
            </div>
          )}

          {dominantEmotion && (
            <div className="absolute bottom-3 right-3 bg-yellow-300 text-black px-3 py-1 rounded">
              {dominantEmotion}
            </div>
          )}

          <div className="absolute top-3 left-3 bg-white/90 text-xs text-black px-2 py-1 rounded">
            <div>
              Mic:{" "}
              {permissionGranted === null
                ? "unknown"
                : permissionGranted
                ? "granted"
                : "denied"}
            </div>
            <div>Audio: {isRunning ? "running" : "stopped"}</div>
            <div>Silent: {isSilent ? "yes" : "no"}</div>
            <div>Calibration: {(calibrationProgress * 100).toFixed(0)}%</div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-4 h-96 overflow-hidden">
          <Line
            data={{
              labels: timestamps,
              datasets: [
                {
                  label: "EAR",
                  data: earData,
                  borderColor: "#3B82F6",
                  fill: false,
                },
                {
                  label: "MAR",
                  data: marData,
                  borderColor: "#EF4444",
                  fill: false,
                },
                {
                  label: "Drowsiness",
                  data: drowsyData,
                  borderColor: "#F59E0B",
                  fill: false,
                },
              ],
            }}
            options={{ responsive: true, maintainAspectRatio: false }}
          />
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-4 h-64">
          <h3 className="font-semibold">Audio</h3>
          <Line
            data={{
              labels: timestamps,
              datasets: [
                {
                  label: "Volume (%)",
                  data: speechVolumeData,
                  borderColor: "#F59E0B",
                  fill: false,
                },
                {
                  label: "Low-band (%)",
                  data: lowBandData,
                  borderColor: "#8B5CF6",
                  fill: false,
                },
              ],
            }}
            options={{ responsive: true, maintainAspectRatio: false }}
          />
        </div>

        <div className="bg-white rounded-lg shadow p-4 h-64">
          <h3 className="font-semibold">Emotion</h3>
          <Bar
            data={{
              labels: emotionLabels,
              datasets: [
                {
                  label: "Emotion Frequency",
                  data: emotionCounts,
                  backgroundColor: "#6366F1",
                },
              ],
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: { legend: { display: false } },
            }}
          />
        </div>

        <div className="bg-white rounded-lg shadow p-4 h-64">
          <h2 className="font-semibold mb-2">Latest Metrics</h2>
          <p>
            <strong>Status:</strong> {status}
          </p>
          <p>
            <strong>Drowsiness:</strong> {(drowsyScore * 100).toFixed(0)}%
          </p>
          <p>
            <strong>Low-band:</strong> {(bandEnergyLow * 100).toFixed(0)}%
          </p>
          <p>
            <strong>Calibration:</strong>{" "}
            {(calibrationProgress * 100).toFixed(0)}%
          </p>
          <p>
            <strong>Blinks:</strong> {blinkCount}
          </p>
          <p>
            <strong>PERCLOS:</strong> {(perclosValue * 100).toFixed(0)}%
          </p>
        </div>
      </div>

      {showDebug && (
        <div className="bg-white rounded-lg shadow p-4">
          <h3 className="font-semibold mb-2">Debug: Audio Envelope</h3>
          <div className="text-sm mb-2">
            Envelope (last ~60):{" "}
            {recentEnvelope(256)
              .envelope.slice(-60)
              .map((v) => Math.round(v))
              .join(", ")}
          </div>
        </div>
      )}
    </div>
  );
}
