"use client";

import { useMemo } from "react";

export default function DashboardSummary({ logs }: { logs: any[] }) {
  const summary = useMemo(() => {
    if (!logs.length) return null;

    const drowsinessVals = logs.map((l) => l.drowsiness ?? 0);
    const avgDrowsiness =
      drowsinessVals.reduce((a, b) => a + b, 0) / drowsinessVals.length;

    const emotionFreq: Record<string, number> = {};
    for (const log of logs) {
      if (log.emotion)
        emotionFreq[log.emotion] = (emotionFreq[log.emotion] || 0) + 1;
    }

    const frequentEmotion =
      Object.entries(emotionFreq).sort((a, b) => b[1] - a[1])[0]?.[0] ||
      "Unknown";

    const drivingScore = Math.max(0, Math.round((1 - avgDrowsiness) * 100));

    let suggestion = "Good performance.";
    if (avgDrowsiness > 0.6) suggestion = "Take a break — you seem tired.";
    else if (avgDrowsiness > 0.4)
      suggestion = "Drive carefully — alertness dropping.";

    return { avgDrowsiness, frequentEmotion, drivingScore, suggestion };
  }, [logs]);

  if (!summary)
    return <p className="text-gray-500 text-center mt-6">No data available.</p>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <div className="bg-white p-4 rounded-lg shadow-md text-center">
        <h3 className="text-sm text-gray-500">Avg Drowsiness</h3>
        <p className="text-2xl font-bold text-blue-600">
          {(summary.avgDrowsiness * 100).toFixed(2)}%
        </p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-md text-center">
        <h3 className="text-sm text-gray-500">Frequent Emotion</h3>
        <p className="text-2xl font-bold text-blue-600">
          {summary.frequentEmotion.toUpperCase()}
        </p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-md text-center">
        <h3 className="text-sm text-gray-500">Driving Score</h3>
        <p className="text-2xl font-bold text-green-600">
          {summary.drivingScore}
        </p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow-md text-center">
        <h3 className="text-sm text-gray-500">Suggestion</h3>
        <p className="text-md font-semibold text-gray-700">
          {summary.suggestion}
        </p>
      </div>
    </div>
  );
}
