"use client";

import { Pie } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";

ChartJS.register(ArcElement, Tooltip, Legend);

export default function EmotionChart({ logs }: { logs: any[] }) {
  // Count each emotion
  const emotionCounts = logs.reduce((acc: Record<string, number>, log) => {
    if (log.emotion) {
      acc[log.emotion] = (acc[log.emotion] || 0) + 1;
    }
    return acc;
  }, {});

  const data = {
    labels: Object.keys(emotionCounts),
    datasets: [
      {
        label: "Emotion Distribution",
        data: Object.values(emotionCounts),
        backgroundColor: [
          "#3B82F6",
          "#EF4444",
          "#10B981",
          "#F59E0B",
          "#8B5CF6",
        ],
      },
    ],
  };

  const options = {
    responsive: true,
    aspectRatio: 1,
    plugins: { legend: { display: true } },
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-md h-full">
      <h2 className="text-lg font-semibold mb-4">Emotion Distribution</h2>
      <Pie data={data} options={options} />
    </div>
  );
}
