import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";

// ---------------- POST ----------------
export async function POST(req: NextRequest) {
  try {
    const {
      driverId,
      tripId,
      avgDrowsiness,
      mostFrequentEmotion,
      speechMoodSummary,
      drivingScore,
      suggestions,
    } = await req.json();

    if (!driverId)
      return NextResponse.json(
        { error: "driverId is required" },
        { status: 400 }
      );

    const driver = await prisma.driver.findUnique({ where: { id: driverId } });
    if (!driver)
      return NextResponse.json({ error: "Driver not found" }, { status: 404 });

    const summary = await prisma.drivingSummary.create({
      data: {
        driverId,
        tripId: tripId || null,
        avgDrowsiness: avgDrowsiness ?? null,
        mostFrequentEmotion: mostFrequentEmotion || null,
        speechMoodSummary: speechMoodSummary || null,
        drivingScore: drivingScore ?? null,
        suggestions: suggestions || null,
        createdAt: new Date(),
      } as Prisma.DrivingSummaryUncheckedCreateInput,
    });

    return NextResponse.json({ success: true, summary }, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Failed to create summary" },
      { status: 500 }
    );
  }
}

// ---------------- GET ----------------
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const driverId = url.searchParams.get("driverId");
    const tripId = url.searchParams.get("tripId");

    if (!driverId) {
      return NextResponse.json(
        { error: "driverId is required" },
        { status: 400 }
      );
    }

    const driver = await prisma.driver.findUnique({ where: { id: driverId } });
    if (!driver) {
      return NextResponse.json({ error: "Driver not found" }, { status: 404 });
    }

    const summaries = await prisma.drivingSummary.findMany({
      where: {
        driverId,
        tripId: tripId || undefined,
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ success: true, summaries });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Failed to fetch summaries" },
      { status: 500 }
    );
  }
}
