import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";

// ---------------- POST ----------------
export async function POST(req: NextRequest) {
  try {
    const { driverId, date, avgDrowsiness, frequentEmotion, totalAlerts } =
      await req.json();

    if (!driverId || !date)
      return NextResponse.json(
        { error: "driverId and date are required" },
        { status: 400 }
      );

    const driver = await prisma.driver.findUnique({ where: { id: driverId } });
    if (!driver)
      return NextResponse.json({ error: "Driver not found" }, { status: 404 });

    const stats = await prisma.driverStats.create({
      data: {
        driverId,
        date: new Date(date),
        avgDrowsiness: avgDrowsiness ?? null,
        frequentEmotion: frequentEmotion || null,
        totalAlerts: totalAlerts ?? null,
        createdAt: new Date(),
      } as Prisma.DriverStatsUncheckedCreateInput,
    });

    return NextResponse.json({ success: true, stats }, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Failed to create stats" },
      { status: 500 }
    );
  }
}

// ---------------- GET ----------------
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const driverId = url.searchParams.get("driverId");
    const date = url.searchParams.get("date");

    if (!driverId)
      return NextResponse.json(
        { error: "driverId is required" },
        { status: 400 }
      );

    const driver = await prisma.driver.findUnique({ where: { id: driverId } });
    if (!driver)
      return NextResponse.json({ error: "Driver not found" }, { status: 404 });

    const stats = await prisma.driverStats.findMany({
      where: {
        driverId,
        date: date ? new Date(date) : undefined,
      },
      orderBy: { date: "desc" },
    });

    return NextResponse.json({ success: true, stats });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Failed to fetch stats" },
      { status: 500 }
    );
  }
}
