// app/api/logs/driver/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";

// ---------------- POST ----------------
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      driverId,
      tripId,
      drowsiness,
      emotion,
      speechMood,
      eyeAspectRatio,
      mouthAspectRatio,
      headPose,
      blinkDetected,
      microExpression,
      speechVolume,
      speechRate,
    } = body;

    // Validate required fields
    if (!driverId) {
      return NextResponse.json(
        { error: "driverId is required" },
        { status: 400 }
      );
    }

    const driver = await prisma.driver.findUnique({
      where: { id: driverId },
    });
    if (!driver) {
      return NextResponse.json({ error: "Driver not found" }, { status: 404 });
    }

    // Log everything including speech data
    const log = await prisma.driverLog.create({
      data: {
        driverId,
        tripId: tripId || null,
        drowsiness: drowsiness !== undefined ? Number(drowsiness) : null,
        emotion: emotion || null,
        speechMood: speechMood || null,
        eyeAspectRatio: eyeAspectRatio ?? null,
        mouthAspectRatio: mouthAspectRatio ?? null,
        headPose: headPose || null,
        blinkDetected: blinkDetected ?? null,
        microExpression: microExpression || null,
        speechVolume: speechVolume ?? null,
        speechRate: speechRate ?? null,
        timestamp: new Date(),
      } as Prisma.DriverLogUncheckedCreateInput,
    });

    // Trigger alert if speech indicates stress or fatigue
    if (speechMood && ["angry", "sad", "tired"].includes(speechMood)) {
      await prisma.alert.create({
        data: {
          driverId,
          tripId: tripId || null,
          type: "SPEECH",
          level: speechMood === "angry" ? 0.7 : 0.5,
          message: `Speech mood detected: ${speechMood}`,
        },
      });
    }

    return NextResponse.json({ success: true, log }, { status: 201 });
  } catch (err) {
    console.error("Driver log error:", err);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

// ---------------- GET ----------------
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const driverId = url.searchParams.get("driverId");
    const tripId = url.searchParams.get("tripId");

    if (!driverId) {
      return NextResponse.json(
        { error: "driverId is required" },
        { status: 400 }
      );
    }

    const driver = await prisma.driver.findUnique({
      where: { id: driverId },
    });
    if (!driver) {
      return NextResponse.json({ error: "Driver not found" }, { status: 404 });
    }

    const logs = await prisma.driverLog.findMany({
      where: {
        driverId,
        tripId: tripId || undefined,
      },
      orderBy: { timestamp: "desc" },
    });

    // Optional: compute average speech metrics for frontend summary
    const avgSpeechVolume =
      logs.reduce((sum, l) => sum + (l.speechVolume || 0), 0) /
      (logs.filter((l) => l.speechVolume != null).length || 1);

    const avgSpeechRate =
      logs.reduce((sum, l) => sum + (l.speechRate || 0), 0) /
      (logs.filter((l) => l.speechRate != null).length || 1);

    return NextResponse.json({
      success: true,
      logs,
      stats: {
        avgSpeechVolume: Number(avgSpeechVolume.toFixed(2)),
        avgSpeechRate: Number(avgSpeechRate.toFixed(2)),
      },
    });
  } catch (err) {
    console.error("Failed to fetch driver logs:", err);
    return NextResponse.json(
      { error: "Failed to fetch driver logs" },
      { status: 500 }
    );
  }
}
