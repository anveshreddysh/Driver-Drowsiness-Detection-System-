import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";

// ---------------- POST ----------------
export async function POST(req: NextRequest) {
  try {
    const { driverId, tripId, type, level, message } = await req.json();

    if (!driverId || !type || !message) {
      return NextResponse.json(
        { error: "driverId, type, and message are required" },
        { status: 400 }
      );
    }

    const driver = await prisma.driver.findUnique({ where: { id: driverId } });
    if (!driver)
      return NextResponse.json({ error: "Driver not found" }, { status: 404 });

    const alert = await prisma.alert.create({
      data: {
        driverId,
        tripId: tripId || null,
        type,
        level: level ?? null,
        message,
        acknowledged: false,
        resolved: false,
        createdAt: new Date(),
      } as Prisma.AlertUncheckedCreateInput,
    });

    return NextResponse.json({ success: true, alert }, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Failed to create alert" },
      { status: 500 }
    );
  }
}

// ---------------- GET ----------------
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const driverId = url.searchParams.get("driverId");
    const tripId = url.searchParams.get("tripId");
    const resolved = url.searchParams.get("resolved");

    if (!driverId) {
      return NextResponse.json(
        { error: "driverId is required" },
        { status: 400 }
      );
    }

    const driver = await prisma.driver.findUnique({ where: { id: driverId } });
    if (!driver) {
      return NextResponse.json({ error: "Driver not found" }, { status: 404 });
    }

    const alerts = await prisma.alert.findMany({
      where: {
        driverId,
        tripId: tripId || undefined,
        resolved: resolved !== null ? resolved === "true" : undefined,
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ success: true, alerts });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Failed to fetch alerts" },
      { status: 500 }
    );
  }
}
